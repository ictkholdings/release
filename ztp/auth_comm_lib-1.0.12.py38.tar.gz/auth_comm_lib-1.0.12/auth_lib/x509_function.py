import datetime
import logging
import os
import re

import cryptography
import cryptography.hazmat
import requests
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from neolib import neo_class, neoutil
from neolib.crypto_util_bin import sha256
from neolib.hexstr_util import tohexstr

from auth_lib.exception import AuthLibVerifyCertException
from auth_lib.x509_handler import X509Handler


def conv_pem_to_b64(contents: str):
	contents = re.sub(r"(-----BEGIN CERTIFICATE-----)|(-----END CERTIFICATE-----)|(\s+)", "", contents)
	return contents


def conv_pem_from_b64(b64_org):
	return f'-----BEGIN CERTIFICATE-----\n{b64_org}\n-----END CERTIFICATE-----'''


def random_cert_sn(size):
	"""Create a positive, non-trimmable serial number for X.509 certificates"""
	raw_sn = bytearray(os.urandom(size))
	raw_sn[0] = raw_sn[0] & 0x7F  # Force MSB bit to 0 to ensure positive integer
	raw_sn[0] = raw_sn[0] | 0x40  # Force next bit to 1 to ensure the integer won't be trimmed in ASN.1 DER encoding
	return int.from_bytes(raw_sn, byteorder='big', signed=False)


def make_verify_cert(signer_ca_cert,reg_code ,signer_ca_priv_key):
	crypto_be = cryptography.hazmat.backends.default_backend()
	builder = x509.CertificateBuilder()
	builder = builder.serial_number(random_cert_sn(16))
	builder = builder.issuer_name(signer_ca_cert.subject)
	builder = builder.not_valid_before(datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc))
	builder = builder.not_valid_after(builder._not_valid_before + datetime.timedelta(days=1))
	builder = builder.subject_name(x509.Name([x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, reg_code)]))
	builder = builder.public_key(signer_ca_cert.public_key())
	signer_ca_ver_cert = builder.sign(
		private_key=signer_ca_priv_key,
		algorithm=hashes.SHA256(),
		backend=crypto_be)
	return signer_ca_ver_cert

def make_verify_cert_pem(signer_ca_cert_pem,reg_code ,signer_ca_priv_key_pem):
	crypto_be = cryptography.hazmat.backends.default_backend()
	signer_ca_priv_key = serialization.load_pem_private_key(
		data=signer_ca_priv_key_pem.encode(),
		password=None,
		backend=crypto_be)
	sx509_ver_cert = make_verify_cert(X509Handler(signer_ca_cert_pem, "PEM").sx509,
	                                  reg_code,
	                                  signer_ca_priv_key)
	inst1 = X509Handler(sx509=sx509_ver_cert)
	return inst1.to_pem()

def verify_ca_cert(inst_ca_cert,inst_verify_cert,reg_code):
	# inst_ca_cert = ParseUsableInfoFromDer(ca_cert, "PEM")
	# inst_verify_cert = ParseUsableInfoFromDer(verify_cert, "PEM")
	if reg_code != inst_verify_cert.get_subject_common_name():
		raise AuthLibVerifyCertException("VERIFY CERT COMMON NAME IS NOT MATCH ")

	try:
		inst_ca_cert.verify_cert(inst_verify_cert.sx509)
	except cryptography.exceptions.InvalidSignature:
		raise AuthLibVerifyCertException("VERIFICATION ERROR verify cert PER ca  ")

	pass


def verify_ca_cert_pem(ca_cert, verify_cert, reg_code):
	print("ca_cert",ca_cert)
	print( "verify_cert",verify_cert)
	inst_ca_cert = X509Handler(ca_cert, "PEM")
	inst_verify_cert = X509Handler(verify_cert, "PEM")
	if reg_code != inst_verify_cert.get_subject_common_name():
		raise AuthLibVerifyCertException("VERIFY CERT COMMON NAME IS NOT MATCH ")

	try:
		inst_ca_cert.verify_cert(inst_verify_cert.sx509)
	except cryptography.exceptions.InvalidSignature:
		raise AuthLibVerifyCertException("VERIFICATION ERROR verify cert PER ca  ")

	pass


def verify_client_cert_pem(cert,cert_key, issuer_cert):
	print("cert",cert)
	print( "issuer_cert",issuer_cert)
	inst_cert = X509Handler(cert, "PEM")
	inst_issuer_cert = X509Handler(issuer_cert, "PEM")
	crypto_be = cryptography.hazmat.backends.default_backend()
	pcert_key = serialization.load_pem_private_key(
		data=cert_key.encode(),
		password=None,
		backend=crypto_be)

	try:
		inst_issuer_cert.verify_cert(inst_cert.sx509)
	except cryptography.exceptions.InvalidSignature:
		raise AuthLibVerifyCertException("VERIFICATION ERROR verify by issuer_cert ")

	pass
	# 인증서와 키를 검증하기 위해 verify cert를 만든다.
	sx509_verify_cert = make_verify_cert(inst_cert.sx509,'aa',pcert_key)
	print(sx509_verify_cert)
	try:
		inst_cert.verify_cert(X509Handler(sx509=sx509_verify_cert).sx509)
	except cryptography.exceptions.InvalidSignature:
		raise AuthLibVerifyCertException("KEY IS NOT MATCH CERT ")





def add_signer_extensions(builder, public_key=None, authority_cert=None):
	if public_key == None:
		public_key = builder._public_key  # Public key not specified, assume its in the builder (cert builder)

	builder = builder.add_extension(
		x509.BasicConstraints(ca=True, path_length=0),
		critical=True)

	builder = builder.add_extension(
		x509.KeyUsage(
			digital_signature=True,
			content_commitment=False,
			key_encipherment=False,
			data_encipherment=False,
			key_agreement=False,
			key_cert_sign=True,
			crl_sign=True,
			encipher_only=False,
			decipher_only=False),
		critical=True)

	builder = builder.add_extension(
		x509.SubjectKeyIdentifier.from_public_key(public_key),
		critical=False)
	subj_key_id_ext = builder._extensions[-1]  # Save newly created subj key id extension

	#x509.SubjectAlternativeName

	if authority_cert:
		# We have an authority certificate, use its subject key id
		builder = builder.add_extension(
			x509.AuthorityKeyIdentifier.from_issuer_subject_key_identifier(
				authority_cert.extensions.get_extension_for_class(x509.SubjectKeyIdentifier).value),
			critical=False)
	else:
		# No authority cert, assume this is a CSR and just use its own subject key id
		builder = builder.add_extension(
			x509.AuthorityKeyIdentifier.from_issuer_subject_key_identifier(subj_key_id_ext.value),
			critical=False)

	return builder

def make_cert_pem(ca_cert, ca_cert_key, cert_key, common_name:str):
	crypto_be = cryptography.hazmat.backends.default_backend()
	builder = x509.CertificateBuilder()
	inst_ca_cert = X509Handler(ca_cert, "PEM")
	priv_key = serialization.load_pem_private_key(
		data=cert_key.encode(),
		password=None,
		backend=crypto_be)
	signer_ca_priv_key = serialization.load_pem_private_key(
		data=ca_cert_key.encode(),
		password=None,
		backend=crypto_be)


	builder = builder.serial_number(random_cert_sn(16))

	builder = builder.issuer_name(inst_ca_cert.sx509.subject)
	not_before = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc)
	if not_before.month == 2 and not_before.day == 29:
		# Compressed certs don't handle leap years, fudge the date a little
		not_before.day = 28
	builder = builder.not_valid_before(not_before)
	builder = builder.not_valid_after(not_before.replace(year=not_before.year + 10))
	#builder = builder.subject_name(signer_ca_csr.subject)
	builder = builder.subject_name(x509.Name([x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, common_name)]))
	builder = builder.public_key(priv_key.public_key())
	builder = add_signer_extensions(
		builder=builder,
		authority_cert=inst_ca_cert.sx509)
	# Sign signer certificate with root
	signer_ca_cert = builder.sign(
		private_key=signer_ca_priv_key,
		algorithm=hashes.SHA256(),
		backend=crypto_be)
	return X509Handler(sx509=signer_ca_cert).to_pem()
