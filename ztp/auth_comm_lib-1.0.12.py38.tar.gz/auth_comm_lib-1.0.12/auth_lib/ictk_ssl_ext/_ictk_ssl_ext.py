import _ssl
import ssl
from typing import List


def build_date():
	pass

def get_peer_cert(ssl_socket_object:_ssl._SSLSocket )->bytes:
	pass

def get_peer_cert_chains(ssl_socket_object:_ssl._SSLSocket )->List[bytes]:
	pass

def set_all_pass(ssl_context:ssl.SSLContext,is_all_pass:bool):
	pass

def check_verify_callback(fn:lambda :True)->int:
	pass
