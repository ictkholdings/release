import ssl
from ssl import SSLSocket,SSLContext
from typing import List

from auth_lib.ictk_ssl_ext import _ictk_ssl_ext


def get_peer_cert(ssl_socket:SSLSocket)->bytes:
	return _ictk_ssl_ext.get_peer_cert(ssl_socket._sslobj)

def get_peer_cert_chains(ssl_socket:SSLSocket)->List[bytes]:
	return _ictk_ssl_ext.get_peer_cert_chains(ssl_socket._sslobj)

def set_all_pass(ssl_context:ssl.SSLContext,is_all_pass:bool):
	return _ictk_ssl_ext.set_all_pass(ssl_context,is_all_pass)


## SSLContext 에 set_all_pass 를 추가 한다.
SSLContext.set_all_pass = set_all_pass

## SSLSocket 에 get_peer_cert_chains 추가 한다.
SSLSocket.get_peer_cert_chains = get_peer_cert_chains


