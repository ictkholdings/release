# auth_comm_lib

## 용도
ICTK HOLDING 에서 사용되는 인증이나 암호 관련 라이브러리를 정리한 라이브러리


