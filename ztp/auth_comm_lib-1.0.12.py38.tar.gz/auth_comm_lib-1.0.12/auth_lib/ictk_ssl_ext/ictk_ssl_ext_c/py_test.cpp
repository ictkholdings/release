#include <stdio.h>
#ifndef __NO_PYTHON_BUILD__
#include <Python.h>
#include <util.h>
 PyObject *my_callback = NULL;


//void print_hex(const char* msg, int len, unsigned char* buf);
 PyObject* hello_world(PyObject *self, PyObject *args) {
	printf("Hello, world!\n");
	unsigned char*  buf = (unsigned char*)"test";
	print_hex("test", 4, buf);


	Py_RETURN_NONE;
}

 PyObject* hello(PyObject *self, PyObject *args) {
	const char* name;
	if (!PyArg_ParseTuple(args, "s", &name)) {
		return NULL;
	}

	printf("Hello, %s!\n", name);
	Py_RETURN_NONE;
}

 PyObject *
spam_system(PyObject *self, PyObject *args)
{
	const char *command;
	int sts;

	if (!PyArg_ParseTuple(args, "s", &command))
		return NULL;
	sts = system(command);

	return PyLong_FromLong(sts);
}


 PyObject *
my_set_callback(PyObject *dummy, PyObject *args)
{
	PyObject *result = NULL;
	PyObject *temp;

	if (PyArg_ParseTuple(args, "O:set_callback", &temp)) {
		if (!PyCallable_Check(temp)) {
			PyErr_SetString(PyExc_TypeError, "parameter must be callable");
			return NULL;
		}
		Py_XINCREF(temp);         /* Add a reference to new callback */
		Py_XDECREF(my_callback);  /* Dispose of previous callback */
		my_callback = temp;       /* Remember new callback */
		/* Boilerplate to return "None" */
		Py_INCREF(Py_None);
		result = Py_None;
	}
	return result;
}
 PyObject *
do_callback(PyObject *dummy, PyObject *args) {

	int arg = 0;
	PyObject *arglist;
	PyObject *result;
	Py_buffer pypubkey;

	if (!PyArg_ParseTuple(args, "z*", &pypubkey))
		return NULL;

    printf("pypubkey %d\n", pypubkey.len);

	print_hex("pypubkey test", pypubkey.len, (unsigned char *)pypubkey.buf);

	/* Time to call the callback */
	printf("test 0 \n");

	arglist = Py_BuildValue("(y#i)", pypubkey.buf,pypubkey.len,23);
	//arglist = Py_BuildValue("(i)", 23);

    printf("test 1\n");
	result = PyObject_CallObject(my_callback, arglist);
    printf("test 2\n");
	 PyBuffer_Release(&pypubkey);
    printf("test 3\n");

	Py_DECREF(arglist);
	printf("test 4\n");
//	if (result == NULL)
//		return NULL; /* Pass error back */
	return result;
	//return PyBytes_FromStringAndSize((const char*)test, strlen(test));
	//Py_RETURN_NONE;
}
#endif