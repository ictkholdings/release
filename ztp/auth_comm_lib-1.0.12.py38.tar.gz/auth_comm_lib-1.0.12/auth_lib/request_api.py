import logging

import requests
from neolib import neoutil

from auth_lib.x509_handler import X509Handler


class RequestApi():
	def __init__(self,base_url,access_token,log_name=""):
		self.base_url_fmt = base_url+"/api/{cmd}/"
		self.access_token = access_token
		self.logger = logging.getLogger(log_name)
		self.log_name = log_name
		self.sessin = requests.Session()

		#s.auth = ('user', 'pass')
		headers = {'Content-type': 'application/json',
		           "Authorization": f"Bearer {self.access_token}"
		           }
		self.sessin.headers.update(headers)


	@classmethod
	def post_api_with_actoken(cls,sessin,url, acc_token,log_name, **kwargs):
		logger = logging.getLogger(log_name)
		# headers = {'Content-type': 'application/json'}
		headers = {'Content-type': 'application/json',
		           "Authorization": f"Bearer {acc_token}"
		           }

		logger.debug("####url### %s", url)
		logger.debug("#### kwargs %s", kwargs)
		logger.debug("#### input %s", neoutil.json_pretty(kwargs))
		res = sessin.post(url, json=kwargs)
		logger.debug(res.text)

		logger.debug("#### output %s", neoutil.json_pretty(res.json()))
		return res.json()

	def post_api(self, cmd, **kwargs):
		# #headers = {'Content-type': 'application/json'}
		# headers = {'Content-type': 'application/json',
		#            "Authorization": "Bearer QNPZC6d82i88Qox1mymvDpImDTTTfq"
		#            }
		# print("#### input",neoutil.json_pretty(kwargs))
		# res = requests.post(cls.base_url_fmt.format(cmd=cmd), json=kwargs, headers=headers)
		#
		#
		# print("#### output",neoutil.json_pretty(res.json()))


		return self.post_api_with_actoken(self.sessin,self.base_url_fmt.format(cmd=cmd),self.access_token,self.log_name,**kwargs)

	def auth_cert(self,cert:str,cert_chain:list):
		return self.post_api("auth_cert", cert=cert,cert_chain=cert_chain)
		pass

	def auth_client_id(self,client_id):
		return self.post_api("auth_client_id", client_id=client_id)

	def del_cert(self,cert_name):
		return self.post_api("del_cert", cert_name=cert_name)
		pass

	def get_cert(self,cert_name):
		return self.post_api("get_cert", cert_name=cert_name)
		pass

	def act_cert(self,cert_name,is_activate=True):
		return self.post_api("act_cert", cert_name=cert_name, is_activate=is_activate)
		pass

	# def _clean_db(self,cert_name,ca_cert_name):
	# 	self._del_cert(cert_name)
	# 	self._del_cert(ca_cert_name)
	#
	# 	pass

	def reg_ca_and_activate(self,ca_cert,verify_cert,is_activate=True):
		post_data = {
			"ca_cert": ca_cert,
			"verify_cert": verify_cert
		}

		res = self.post_api("reg_ca", **post_data)
		ca_cert_name = X509Handler(ca_cert, encoding="PEM").to_hash().hexstr

		res1 = self.act_cert(ca_cert_name,is_activate)

		return res,res1
